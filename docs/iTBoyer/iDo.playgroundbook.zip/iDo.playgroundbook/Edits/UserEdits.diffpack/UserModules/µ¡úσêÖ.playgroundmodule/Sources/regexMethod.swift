//  Copyright © 2016-2019 Apple Inc. All rights reserved.
import Foundation
import UIKit
// 共享代码
// 此文件中编写的代码在这本 Playground 中的所有页面均可用。
//正则过滤
public func check(str: String)->String {
    // 使用正则表达式一定要加try语句
    var regexStr = ""
    do {
        // - 1、创建规则
        let pattern = "http.?"
        // - 2、创建正则表达式对象
        let regex = try NSRegularExpression(pattern: pattern, options: NSRegularExpression.Options.caseInsensitive)
        // - 3、开始匹配
        let res = regex.matches(in: str, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, str.count))
        // 输出结果
        for checkingRes in res {
            regexStr = (str as NSString).substring(with: checkingRes.range)
        }
    }
    catch {
        print(error)
    }
    return regexStr
}       

