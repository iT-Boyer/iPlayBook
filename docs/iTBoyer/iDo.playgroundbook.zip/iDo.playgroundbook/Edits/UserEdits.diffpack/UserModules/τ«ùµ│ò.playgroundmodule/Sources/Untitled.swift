
import Foundation
public class opration:NSObject{
    var firstNum = 0
    var secondNum = 0
    func getResultNum() -> Double{
        return 0
    }
}
public class addOpt:opration{
    override init() {
        super.init()
    }
    override func getResultNum() -> Double {
        var result = self.firstNum + self.secondNum
        return Double(result)
    }
}
public class jianfaOpt:opration{
    override func getResultNum() -> Double {
        return Double(self.firstNum - self.secondNum)
    }
}
public class factory
{
    var opt:opration!
    public func createFunc(_ flag:String) -> opration{
        switch flag{
        case "+":
            opt = addOpt()
        case "-":
            opt = jianfaOpt()
        default:
            opt = nil
        }
        return opt
    }
}
