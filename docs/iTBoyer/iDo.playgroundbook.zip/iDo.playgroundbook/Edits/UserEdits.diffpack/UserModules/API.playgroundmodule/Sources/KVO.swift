//  Copyright © 2016-2019 Apple Inc. All rights reserved.
import Foundation
//用户类
 class User: NSObject{
    @objc private var name:String = ""  //姓名
    @objc var nickname:String?  //昵称
    @objc var age:Int = 0  //年龄
    @objc var emails:[String]?  //邮件地址
}

public class testKVO {
    var user:User!
    public var kvoName = ""
    public var kvoNick = ""
    public var kvoEmails = ""
    public init(){
        user = User()
        forValue()
    }

    func forValue() {
        user.setValue("asdf", forKey: "name")
        user.setValue("dog", forKey: "nickname")
        user.age = 1001
        user.emails = ["hangge@hangge.com","system@hangge.com"]
    }
    public func showValue() -> String{
        kvoName = user.value(forKey: "name") as! String
        kvoNick = user.value(forKey: "nickname") as! String
        let emails:Array = user.value(forKey: "emails") as! Array<Any>
        var emailsstr = ""
        for i in 0 ..< emails.count {
            emailsstr = "\(emailsstr) \( emails[i])"
        }
        
        
//          kvoEmails =  as
        return kvoName + kvoNick + emailsstr
    }
}
