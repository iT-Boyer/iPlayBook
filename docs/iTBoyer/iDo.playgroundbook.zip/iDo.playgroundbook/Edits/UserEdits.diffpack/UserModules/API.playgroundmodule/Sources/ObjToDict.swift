
import Foundation
import UIKit
extension NSObject
{
    public func dictForViews(views:[UIView]) -> [String : UIView] {
        var count:UInt32 = 0
        var dicts:[String : UIView] = [:]
        let ivars = class_copyIvarList(self.classForCoder, &count)
        for var i in 0..<Int(count){
            let obj = object_getIvar(self, (ivars?[i])!)
            if let temp = obj as?
                UIView{
                views.contains(temp)
                let name = try! String.init(from: ivar_getName(ivars![i]) as! Decoder)
                //                  let name = String.fromCString(ivar_getName(ivars[i]))!
                dicts[name] = temp
                if dicts.count == views.count{ break }
            }
        }
        
        free(ivars)
        
        return dicts
    }
}
